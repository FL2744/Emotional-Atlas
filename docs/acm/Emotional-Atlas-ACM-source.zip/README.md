<div align="left">

# Emotional Atlas

Technical paper: [PDF](Emotional-Atlas.pdf) · [LaTeX](main.tex) · [Markdown](TECHNICAL_PAPER.md) · [Source bundle](Source.zip)

Emotional Atlas: Emotional Geometry, Textual Evolution, and Shape-Guided Revision

William Taggart, Modern and Classical Languages and Literatures, Virginia Tech.

Original project: [GitHub](https://github.com/FL2744/Emotional-Atlas).

Build with `tectonic main.tex`, or use a LaTeX installation with the `acmart` class and BibTeX. Figure assets and bibliography files are included.

</div>
